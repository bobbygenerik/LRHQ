# Graph Report - roku  (2026-06-14)

## Corpus Check
- 1 files · ~36,154 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 8 nodes · 7 edges · 1 communities
- Extraction: 100% EXTRACTED · 0% INFERRED · 0% AMBIGUOUS
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `57f2b66e`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Community 0|Community 0]]

## God Nodes (most connected - your core abstractions)
1. `LivingRoom HQ — Roku` - 7 edges
2. `Important platform differences` - 1 edges
3. `Project layout` - 1 edges
4. `Configure the playlist + guide` - 1 edges
5. `Sideload (developer mode)` - 1 edges
6. `What's implemented` - 1 edges
7. `Roadmap (remaining Android parity)` - 1 edges

## Surprising Connections (you probably didn't know these)
- None detected - all connections are within the same source files.

## Import Cycles
- None detected.

## Communities (1 total, 0 thin omitted)

### Community 0 - "Community 0"
Cohesion: 0.25
Nodes (7): Configure the playlist + guide, Important platform differences, LivingRoom HQ — Roku, Project layout, Roadmap (remaining Android parity), Sideload (developer mode), What's implemented

## Knowledge Gaps
- **6 isolated node(s):** `Important platform differences`, `Project layout`, `Configure the playlist + guide`, `Sideload (developer mode)`, `What's implemented` (+1 more)
  These have ≤1 connection - possible missing edges or undocumented components.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **What connects `Important platform differences`, `Project layout`, `Configure the playlist + guide` to the rest of the system?**
  _6 weakly-connected nodes found - possible documentation gaps or missing edges._